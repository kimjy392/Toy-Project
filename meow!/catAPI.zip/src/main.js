new App(document.querySelector("#App"));
